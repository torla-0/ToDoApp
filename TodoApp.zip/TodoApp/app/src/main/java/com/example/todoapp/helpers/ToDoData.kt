package com.example.todoapp.helpers

data class ToDoData(val taskId: String, var task: String)
